import os
import time
import math
from typing import Any, Dict, List, Optional

import httpx
from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel, Field
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

APP_TITLE = "Cep Futbol Analiz"
API_FOOTBALL_KEY = os.getenv("API_FOOTBALL_KEY", "").strip()
FOOTBALL_DATA_TOKEN = os.getenv("FOOTBALL_DATA_TOKEN", "").strip()
SPORTMONKS_TOKEN = os.getenv("SPORTMONKS_TOKEN", "").strip()
STATSBOMB_TOKEN = os.getenv("STATSBOMB_TOKEN", "").strip()

API_FOOTBALL_BASE = "https://v3.football.api-sports.io"
FOOTBALL_DATA_BASE = "https://api.football-data.org/v4"
SPORTMONKS_BASE = "https://api.sportmonks.com/v3/football"

app = FastAPI(title=APP_TITLE, version="1.0.0")
app.mount("/static", StaticFiles(directory="static"), name="static")

# Small in-memory cache to reduce free API usage. A production deployment can use Redis.
_CACHE: Dict[str, tuple[float, Any]] = {}


def cache_get(key: str):
    item = _CACHE.get(key)
    if not item:
        return None
    expires, value = item
    if expires < time.time():
        _CACHE.pop(key, None)
        return None
    return value


def cache_set(key: str, value: Any, ttl: int = 600):
    _CACHE[key] = (time.time() + ttl, value)


async def api_football_get(path: str, params: dict):
    if not API_FOOTBALL_KEY:
        raise HTTPException(status_code=424, detail="API_FOOTBALL_KEY ayarlanmamış. README dosyasındaki adımları izleyip anahtarı sunucuya ekle.")
    url = f"{API_FOOTBALL_BASE}/{path.lstrip('/')}"
    headers = {"x-apisports-key": API_FOOTBALL_KEY}
    try:
        async with httpx.AsyncClient(timeout=20) as client:
            response = await client.get(url, headers=headers, params=params)
        if response.status_code in (401, 403):
            raise HTTPException(status_code=502, detail="API-Sports anahtarı geçersiz olabilir veya erişim izni yok.")
        response.raise_for_status()
        payload = response.json()
        if payload.get("errors"):
            raise HTTPException(status_code=502, detail=f"API-Sports hata döndürdü: {payload['errors']}")
        return payload
    except HTTPException:
        raise
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=502, detail=f"API-Sports bağlantı hatası: {exc.__class__.__name__}")


@app.get("/")
def home():
    return FileResponse("static/index.html")


class ApiKeyInput(BaseModel):
    api_key: str = Field(min_length=8, max_length=300)


@app.post("/api/config/api-sports")
def configure_api_sports(body: ApiKeyInput):
    """Set API-Sports key in this running server process. Render restarts clear this;
    for persistent deployments, configure API_FOOTBALL_KEY in Render Environment."""
    global API_FOOTBALL_KEY
    API_FOOTBALL_KEY = body.api_key.strip()
    if not API_FOOTBALL_KEY:
        raise HTTPException(status_code=400, detail="API anahtarı boş olamaz.")
    return {"ok": True, "configured": True, "message": "API anahtarı bu sunucu oturumuna kaydedildi."}


@app.get("/api/health")
def health():
    # Never return API keys or tokens from this endpoint.
    return {
        "ok": True,
        "app": APP_TITLE,
        "providers": {
            "api_sports": {"configured": bool(API_FOOTBALL_KEY), "role": "Türkiye ligleri için ilk canlı veri adayı"},
            "football_data": {"configured": bool(FOOTBALL_DATA_TOKEN), "role": "Ek fikstür kaynağı; Türkiye ligleri ücretsiz kapsamda olmayabilir"},
            "sportmonks": {"configured": bool(SPORTMONKS_TOKEN), "role": "Alternatif futbol verisi; Türkiye ligleri için paket kapsamını kontrol et"},
            "statsbomb": {"configured": bool(STATSBOMB_TOKEN), "role": "İzinli erişim varsa gelişmiş analiz verisi; oran sağlayıcısı değildir"},
            "mackolik": {"configured": False, "role": "Doğrudan entegrasyon henüz yapılmadı; izinli erişim doğrulanmalı"},
        },
        "note": "configured yalnızca sunucu ortamında anahtar bulunduğunu gösterir; erişimin/lig kapsamının çalıştığını garanti etmez."
    }


@app.get("/api/matches")
async def matches(
    league: int = Query(203, description="API-Football lig ID: 203 Süper Lig, 204 1. Lig (önce servis panelinde doğrula)"),
    season: int = Query(2026, description="Sezon başlangıç yılı"),
    next_n: Optional[int] = Query(None, ge=1, le=20),
    date: Optional[str] = Query(None, description="YYYY-MM-DD"),
):
    params: Dict[str, Any] = {"league": league, "season": season}
    if next_n:
        params["next"] = next_n
    if date:
        params["date"] = date
    key = "matches:" + str(sorted(params.items()))
    cached = cache_get(key)
    if cached is not None:
        return {"cached": True, **cached}
    payload = await api_football_get("fixtures", params)
    response = {"provider": "API-Sports / API-Football", "results": payload.get("results", 0), "matches": payload.get("response", [])}
    cache_set(key, response, 300)
    return response


@app.get("/api/odds")
async def odds(fixture: int = Query(..., gt=0)):
    key = f"odds:{fixture}"
    cached = cache_get(key)
    if cached is not None:
        return {"cached": True, **cached}
    payload = await api_football_get("odds", {"fixture": fixture})
    normalized = normalize_api_football_odds(payload.get("response", []))
    response = {"provider": "API-Sports / API-Football", "fixture": fixture, "results": payload.get("results", 0), "odds": normalized}
    cache_set(key, response, 180)
    return response


def normalize_api_football_odds(rows: List[dict]) -> List[dict]:
    """Normalize API-Football bookmaker/bet/value structures for comparison."""
    output: List[dict] = []
    for row in rows:
        fixture = row.get("fixture", {}) or {}
        for bookmaker in row.get("bookmakers", []) or []:
            book_name = bookmaker.get("name", "Bilinmeyen kaynak")
            for bet in bookmaker.get("bets", []) or []:
                market = bet.get("name", "Bilinmeyen pazar")
                for value in bet.get("values", []) or []:
                    raw = value.get("odd")
                    try:
                        odd = float(raw)
                    except (TypeError, ValueError):
                        continue
                    if odd <= 1:
                        continue
                    output.append({
                        "bookmaker": book_name,
                        "market": market,
                        "selection": value.get("value", ""),
                        "odd": odd,
                        "implied_probability_pct": round(100 / odd, 2),
                        "updated_at": bookmaker.get("update") or row.get("update") or None,
                        "fixture_id": fixture.get("id"),
                    })
    return output


@app.get("/api/compare")
async def compare(fixture: int = Query(..., gt=0)):
    data = await odds(fixture)
    groups: Dict[str, List[dict]] = {}
    for item in data.get("odds", []):
        group_key = f"{item['market']} :: {item['selection']}"
        groups.setdefault(group_key, []).append(item)
    comparisons = []
    for key, items in groups.items():
        items.sort(key=lambda x: x["odd"], reverse=True)
        comparisons.append({
            "market_selection": key,
            "best_odd": items[0]["odd"],
            "best_source": items[0]["bookmaker"],
            "sources_count": len(items),
            "sources": items,
        })
    comparisons.sort(key=lambda x: x["market_selection"])
    return {"fixture": fixture, "comparisons": comparisons, "note": "Yalnızca API'nin döndürdüğü kaynaklar karşılaştırılır; tüm bahis şirketlerinin yer alması garanti değildir."}


def poisson(lam: float, k: int) -> float:
    return math.exp(-lam) * (lam ** k) / math.factorial(k)


@app.get("/api/quick-analysis")
def quick_analysis(home_xg: float = Query(..., ge=0, le=6), away_xg: float = Query(..., ge=0, le=6)):
    """A simple independent Poisson estimate using user-entered expected goals.
    This is a calculator only; it does not claim these xG values came from a provider.
    """
    home_win = draw = away_win = over25 = btts = 0.0
    max_goals = 10
    for h in range(max_goals + 1):
        ph = poisson(home_xg, h)
        for a in range(max_goals + 1):
            p = ph * poisson(away_xg, a)
            if h > a:
                home_win += p
            elif h == a:
                draw += p
            else:
                away_win += p
            if h + a >= 3:
                over25 += p
            if h > 0 and a > 0:
                btts += p
    return {
        "input": {"home_xg": home_xg, "away_xg": away_xg},
        "probabilities_pct": {
            "home_win": round(home_win * 100, 2),
            "draw": round(draw * 100, 2),
            "away_win": round(away_win * 100, 2),
            "over_2_5": round(over25 * 100, 2),
            "both_teams_score": round(btts * 100, 2),
        },
        "disclaimer": "Bu hesaplama yalnızca girilen xG değerlerine dayalı matematiksel tahmindir; canlı istatistik veya kesin sonuç değildir."
    }


@app.get("/api/providers")
def providers():
    return health()


# Optional generic Football-Data.org connectivity test. The provider's coverage and tier
# must be checked before relying on it for Turkey's top two divisions.
@app.get("/api/provider-tests/football-data")
async def test_football_data():
    if not FOOTBALL_DATA_TOKEN:
        raise HTTPException(status_code=424, detail="FOOTBALL_DATA_TOKEN ayarlanmamış.")
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            r = await client.get(f"{FOOTBALL_DATA_BASE}/competitions", headers={"X-Auth-Token": FOOTBALL_DATA_TOKEN})
        if r.status_code in (401, 403):
            raise HTTPException(status_code=502, detail="Football-Data.org token geçersiz olabilir veya bu veriye izin yok.")
        r.raise_for_status()
        data = r.json()
        competitions = data.get("competitions", [])
        turkey = [c for c in competitions if "turkey" in str(c.get("area", {}).get("name", "")).lower() or "turkey" in str(c.get("name", "")).lower()]
        return {"ok": True, "competition_count_returned": len(competitions), "turkey_matches_in_response": turkey, "note": "Bu test yalnızca token erişimini kontrol eder; ücretsiz lig kapsamını ayrıca doğrula."}
    except HTTPException:
        raise
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=502, detail=f"Football-Data.org bağlantı hatası: {exc.__class__.__name__}")
