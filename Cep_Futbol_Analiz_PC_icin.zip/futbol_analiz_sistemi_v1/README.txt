CEP FUTBOL ANALİZ - V1 BAŞLANGIÇ PROJESİ
========================================

Bu proje Android telefondaki Chrome'da açılabilen mobil uyumlu web ekranı + sunucu tarafı API bağlantısı iskeletidir.
Şu anda API-Sports / API-Football için gerçek maç fikstürü ve oran endpoint bağlantısı uygulanmıştır.
Canlı veri ancak kendi API anahtarını sunucuya ekledikten sonra çalışır. Bu ZIP'in içinde API anahtarı yoktur.

ÖZELLİKLER
- Mobil uyumlu ekran
- Türkiye Süper Lig (varsayılan API-Football league ID 203) ve 1. Lig (varsayılan 204) fikstür sorgusu
- API-Sports / API-Football üzerinden maç listesi alma
- API'nin döndürdüğü bahis oranlarını market/seçim bazında karşılaştırma
- API çağrılarını azaltmak için kısa süreli sunucu önbelleği
- xG girilerek Poisson olasılık hesaplayıcı
- API anahtarlarının tarayıcıya gönderilmemesi
- Sağlayıcıların sunucuda anahtarı bulunup bulunmadığını gösterme

ÖNEMLİ SINIRLAR
- API-Sports anahtarı/hesabı olmadan canlı maç veya oran verisi alınmaz.
- Ücretsiz pakette günlük istek limiti vardır; güncel sınırı API-Sports hesabından doğrula.
- Oran endpoint'i her maç veya her market için veri döndürmeyebilir.
- Football-Data.org, Sportmonks ve StatsBomb burada sağlayıcı durum bilgisi olarak yer alır; henüz gerçek maç verisi/odds adapter'ı olarak bağlanmış değildir.
- Football-Data.org'un ücretsiz kapsamı Türkiye Süper Lig ve 1. Lig'i içermeyebilir.
- Sportmonks ücretsiz kapsamı Türkiye liglerini içermeyebilir; ücretli plan fiyatı ve kapsamı kontrol edilmeli.
- StatsBomb Data login tek başına API erişimi anlamına gelmez; verilen yetkili API/ürün erişimi gerekir ve tipik olarak oran sağlayıcısı değildir.
- Maçkolik bağlantısı yapılmadı. Resmî/izinli erişim yöntemi bulunmadan uygulama verilerini kazımaya çalışmaz.
- Bu araç tahmin/karşılaştırma aracıdır; kesin sonuç veya kâr garantisi vermez.

YEREL ÇALIŞTIRMA (Windows)
1. Python 3.11 veya güncel bir Python 3 sürümü kur.
2. Bu klasörde Komut İstemi aç.
3. Şunları çalıştır:
   py -m venv .venv
   .venv\Scripts\activate
   pip install -r requirements.txt
4. API-Sports anahtarını ortam değişkeni olarak ekle (PowerShell):
   $env:API_FOOTBALL_KEY="BURAYA_KENDI_ANAHTARIN"
5. Sunucuyu başlat:
   uvicorn app:app --host 127.0.0.1 --port 8000
6. Bilgisayarda http://127.0.0.1:8000 aç.

TELEFONDAN ERİŞİM
- Bilgisayar ve telefon aynı Wi-Fi'deyse sunucuyu şu komutla başlat:
  uvicorn app:app --host 0.0.0.0 --port 8000
- Bilgisayarın yerel IP adresini öğren ve telefonda http://BILGISAYAR_IP:8000 adresini aç.
- İnternet üzerinden her yerden erişmek için HTTPS kullanan bir sunucuya deploy et. Render için render.yaml eklenmiştir.

RENDER'A YÜKLEME
1. Proje klasörünü kendi GitHub hesabındaki özel bir repoya yükle.
2. Render'da New > Web Service seçip repoyu bağla.
3. render.yaml ayarlarını kullan.
4. Render Environment bölümünde API_FOOTBALL_KEY anahtarını ekle.
5. Deploy tamamlanınca verilen HTTPS adresini Android Chrome'da aç.
6. API anahtarını GitHub'a, HTML dosyasına veya sohbet mesajına yazma.

LİG ID / SEZON
Varsayılan ID'ler API-Football'da Türkiye Süper Lig 203 ve 1. Lig 204 olarak ayarlanmıştır. Servis panelinde ilgili sezon kapsamını doğrula. 2026 sezon parametresi, 2026-27 sezon başlangıç yılı olarak kullanılır.

API GÜVENLİĞİ
- Anahtar yalnızca server-side environment variable olarak saklanır.
- /api/health anahtarın kendisini asla döndürmez.
- Herkese açık deploy'da API tüketim limitini takip et; gerekirse uygulamaya giriş koruması ekle.
- Üretim kullanımında cache'i Redis/DB'ye taşı, istek sınırı ve kullanıcı kimlik doğrulaması ekle.
